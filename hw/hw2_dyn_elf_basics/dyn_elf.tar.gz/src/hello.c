#include "hello.h"

int main() { printf(HELLO); }
