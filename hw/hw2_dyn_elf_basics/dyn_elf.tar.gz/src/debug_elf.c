#include "debug_elf.h"
#ifdef DEBUG_ELF
// <solution>
// Print an Elf64_Sym.
void debug_esym(const Elf64_Sym *sym) {
  debug_printf("Elf64_Sym:\n");
  debug_printf("  st_name: %u\n", sym->st_name);
  debug_printf("  st_info: 0x%x (binding=%u, type=%u)\n", sym->st_info,
               sym->st_info >> 4, sym->st_info & 0xF);
  debug_printf("  st_other: 0x%x\n", sym->st_other);
  debug_printf("  st_shndx: %u\n", sym->st_shndx);
  debug_printf("  st_value: 0x%lx\n", sym->st_value);
  debug_printf("  st_size: %lu\n", sym->st_size);
}

// Print an Elf64_Shdr.
void debug_shdr(const Elf64_Shdr *shdr) {
  debug_printf("Elf64_Shdr:\n");
  debug_printf("  sh_name: %u\n", shdr->sh_name);
  debug_printf("  sh_type: %u\n", shdr->sh_type);
  debug_printf("  sh_flags: 0x%lx\n", shdr->sh_flags);
  debug_printf("  sh_addr: 0x%lx\n", shdr->sh_addr);
  debug_printf("  sh_offset: 0x%lx\n", shdr->sh_offset);
  debug_printf("  sh_size: %lu\n", shdr->sh_size);
  debug_printf("  sh_link: %u\n", shdr->sh_link);
  debug_printf("  sh_info: %u\n", shdr->sh_info);
  debug_printf("  sh_addralign: %lu\n", shdr->sh_addralign);
  debug_printf("  sh_entsize: %lu\n", shdr->sh_entsize);
}

// Print an Elf64_Phdr.
void debug_phdr(const Elf64_Phdr *phdr) {
  debug_printf("Elf64_Phdr:\n");
  debug_printf("  p_type: %u\n", phdr->p_type);
  debug_printf("  p_flags: %u\n", phdr->p_flags);
  debug_printf("  p_offset: 0x%lx\n", phdr->p_offset);
  debug_printf("  p_vaddr: 0x%lx\n", phdr->p_vaddr);
  debug_printf("  p_paddr: 0x%lx\n", phdr->p_paddr);
  debug_printf("  p_filesz: %lu\n", phdr->p_filesz);
  debug_printf("  p_memsz: %lu\n", phdr->p_memsz);
  debug_printf("  p_align: %lu\n", phdr->p_align);
}

// Print an Elf64_Ehdr.
void debug_ehdr(const Elf64_Ehdr *ehdr) {
  debug_printf("Elf64_Ehdr:\n");
  debug_printf("  e_ident: ");
  for (int i = 0; i < EI_NIDENT; i++) {
    debug_printf("%02x ", ehdr->e_ident[i]);
  }
  debug_printf("\n");
  debug_printf("  e_type: %u\n", ehdr->e_type);
  debug_printf("  e_machine: %u\n", ehdr->e_machine);
  debug_printf("  e_version: %u\n", ehdr->e_version);
  debug_printf("  e_entry: 0x%lx\n", ehdr->e_entry);
  debug_printf("  e_phoff: 0x%lx\n", ehdr->e_phoff);
  debug_printf("  e_shoff: 0x%lx\n", ehdr->e_shoff);
  debug_printf("  e_flags: %u\n", ehdr->e_flags);
  debug_printf("  e_ehsize: %u\n", ehdr->e_ehsize);
  debug_printf("  e_phentsize: %u\n", ehdr->e_phentsize);
  debug_printf("  e_phnum: %u\n", ehdr->e_phnum);
  debug_printf("  e_shentsize: %u\n", ehdr->e_shentsize);
  debug_printf("  e_shnum: %u\n", ehdr->e_shnum);
  debug_printf("  e_shstrndx: %u\n", ehdr->e_shstrndx);
}

// <solution>

#else
// When DEBUG is not defined, make these functions no-ops.
#define debug_esym(sym) ((void)0)
#define debug_shdr(shdr) ((void)0)
#define debug_phdr(phdr) ((void)0)
#define debug_ehdr(ehdr) ((void)0)
#endif
