// elf_printf.c
#include <elf.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int (*my_printf_t)(const char *, ...);

int main(void) {
    return 0;
}
