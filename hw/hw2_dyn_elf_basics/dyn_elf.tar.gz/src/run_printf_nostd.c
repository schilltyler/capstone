

void _start() {
  // Your solution here
  // feel free to add functions and types as needed
}
