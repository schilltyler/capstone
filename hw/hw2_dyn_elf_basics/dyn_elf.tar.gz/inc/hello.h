#include "stdio.h"

#define HELLO "hello world!\n"
